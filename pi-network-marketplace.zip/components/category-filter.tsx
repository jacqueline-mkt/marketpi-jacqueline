"use client"

import { Button } from "@/components/ui/button"
import { categories } from "@/lib/products"

interface CategoryFilterProps {
  selectedCategory: string
  onSelectCategory: (category: string) => void
}

export function CategoryFilter({ selectedCategory, onSelectCategory }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {categories.map((category) => (
        <Button
          key={category}
          variant={selectedCategory === category ? "default" : "secondary"}
          size="sm"
          onClick={() => onSelectCategory(category)}
          className={
            selectedCategory === category
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          }
        >
          {category}
        </Button>
      ))}
    </div>
  )
}
