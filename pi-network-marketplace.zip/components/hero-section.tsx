"use client"

import { Button } from "@/components/ui/button"

function PiLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="50" cy="50" r="48" fill="currentColor" />
      <text
        x="50"
        y="68"
        textAnchor="middle"
        fill="white"
        fontSize="52"
        fontWeight="bold"
        fontFamily="sans-serif"
      >
        π
      </text>
    </svg>
  )
}

function ArrowRightIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M5 12h14" />
      <path d="m12 5 7 7-7 7" />
    </svg>
  )
}

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-card border-b border-border">
      {/* Background glow effect */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 mb-6">
            <PiLogo className="h-10 w-10 text-primary" />
            <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
              Powered by Pi Network
            </span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight text-balance">
            Buy and Sell with{" "}
            <span className="text-primary">Pi Cryptocurrency</span>
          </h1>
          
          <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
            Welcome to MarketPi Jacqueline — the trusted marketplace for Pi pioneers. 
            Discover unique products and pay securely with your Pi coins.
          </p>
          
          <div className="mt-8 flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
              Start Shopping
              <ArrowRightIcon className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-border hover:bg-secondary">
              List Your Products
            </Button>
          </div>
          
          {/* Stats */}
          <div className="mt-12 grid grid-cols-3 gap-8 max-w-md">
            <div>
              <p className="text-2xl md:text-3xl font-bold text-foreground">10K+</p>
              <p className="text-sm text-muted-foreground">Products</p>
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-foreground">5K+</p>
              <p className="text-sm text-muted-foreground">Pioneers</p>
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-foreground">50K+</p>
              <p className="text-sm text-muted-foreground">Transactions</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
