"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { ProductCard } from "@/components/product-card"
import { CategoryFilter } from "@/components/category-filter"
import { getProductsByCategory } from "@/lib/products"

function PiLogo({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="50" cy="50" r="48" fill="currentColor" />
      <text
        x="50"
        y="68"
        textAnchor="middle"
        fill="white"
        fontSize="52"
        fontWeight="bold"
        fontFamily="sans-serif"
      >
        π
      </text>
    </svg>
  )
}

export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState("All Categories")
  const filteredProducts = getProductsByCategory(selectedCategory)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      
      <main className="container mx-auto px-4 py-12">
        {/* Section Header */}
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">
              Featured Products
            </h2>
            <p className="mt-1 text-muted-foreground">
              Discover amazing products from Pi pioneers
            </p>
          </div>
          <CategoryFilter
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No products found in this category.</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card mt-16">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <PiLogo className="h-8 w-8 text-primary" />
                <span className="text-lg font-bold text-foreground">
                  MarketPi <span className="text-primary">Jacqueline</span>
                </span>
              </div>
              <p className="text-muted-foreground max-w-md">
                The trusted marketplace for Pi Network pioneers. Buy and sell products 
                securely using Pi cryptocurrency.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Marketplace</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Browse Products</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Sell Items</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Categories</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Trending</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Safety Tips</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Pi Network</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
            <p>&copy; 2026 MarketPi Jacqueline. Built for the Pi Network community.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
