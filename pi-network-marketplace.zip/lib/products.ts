export interface Product {
  id: string
  name: string
  description: string
  price: number
  image: string
  category: string
  seller: string
  rating: number
  reviews: number
  inStock: boolean
}

export const products: Product[] = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    description: "Premium noise-canceling wireless headphones with 30-hour battery life. Experience crystal-clear audio with deep bass and comfortable over-ear design.",
    price: 45,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop",
    category: "Electronics",
    seller: "TechStore Pi",
    rating: 4.8,
    reviews: 124,
    inStock: true,
  },
  {
    id: "2",
    name: "Vintage Leather Backpack",
    description: "Handcrafted genuine leather backpack with multiple compartments. Perfect for work, travel, or everyday use with a timeless design.",
    price: 85,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop",
    category: "Fashion",
    seller: "LeatherCraft Co",
    rating: 4.6,
    reviews: 89,
    inStock: true,
  },
  {
    id: "3",
    name: "Smart Fitness Watch",
    description: "Track your health and fitness with this feature-packed smartwatch. Heart rate monitoring, GPS, sleep tracking, and 7-day battery life.",
    price: 120,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
    category: "Electronics",
    seller: "FitGear Hub",
    rating: 4.9,
    reviews: 256,
    inStock: true,
  },
  {
    id: "4",
    name: "Organic Green Tea Set",
    description: "Premium organic green tea collection from Japanese highlands. Includes 5 varieties in elegant packaging, perfect for tea enthusiasts.",
    price: 28,
    image: "https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&h=400&fit=crop",
    category: "Food & Drinks",
    seller: "TeaTime Paradise",
    rating: 4.7,
    reviews: 67,
    inStock: true,
  },
  {
    id: "5",
    name: "Minimalist Desk Lamp",
    description: "Modern LED desk lamp with adjustable brightness and color temperature. USB charging port and touch controls for a clutter-free workspace.",
    price: 35,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop",
    category: "Home & Garden",
    seller: "HomeStyle Plus",
    rating: 4.5,
    reviews: 43,
    inStock: true,
  },
  {
    id: "6",
    name: "Professional Camera Drone",
    description: "4K camera drone with 3-axis gimbal stabilization. 30-minute flight time, obstacle avoidance, and intelligent flight modes.",
    price: 350,
    image: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400&h=400&fit=crop",
    category: "Electronics",
    seller: "SkyView Tech",
    rating: 4.8,
    reviews: 178,
    inStock: false,
  },
  {
    id: "7",
    name: "Handmade Ceramic Vase",
    description: "Beautiful artisan ceramic vase with unique glazed finish. Each piece is one-of-a-kind, perfect for home decoration.",
    price: 55,
    image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=400&h=400&fit=crop",
    category: "Home & Garden",
    seller: "ArtisanCrafts",
    rating: 4.4,
    reviews: 32,
    inStock: true,
  },
  {
    id: "8",
    name: "Mechanical Gaming Keyboard",
    description: "RGB backlit mechanical keyboard with Cherry MX switches. Programmable keys, detachable wrist rest, and durable aluminum frame.",
    price: 95,
    image: "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400&h=400&fit=crop",
    category: "Electronics",
    seller: "GamerZone",
    rating: 4.7,
    reviews: 201,
    inStock: true,
  },
]

export const categories = [
  "All Categories",
  "Electronics",
  "Fashion",
  "Home & Garden",
  "Food & Drinks",
]

export function getProductById(id: string): Product | undefined {
  return products.find(product => product.id === id)
}

export function getProductsByCategory(category: string): Product[] {
  if (category === "All Categories") return products
  return products.filter(product => product.category === category)
}
